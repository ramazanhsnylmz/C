#include <stdio.h>

int main()
{
/*1.ÖRNEK DEĞİŞKENLER*/
int g_intSayi_1 = 8, g_intSayi_2 = 6, g_intSayi_3 = 4, sonuc = 0;
sonuc = g_intSayi_1 + g_intSayi_2 + g_intSayi_3;
printf("%d", sonuc); //%d tam sayı yazarken kullanıyoruz.
printf("\nRamazan Hasan Yilmaz \t2024"); //\n bir alt satıra geçirir, \t tab kadar boşluk bırakır.
return 0;
}