#include <stdio.h>
#include <stdlib.h> //malloc fonksiyonunu kullanmak için ekledik.
/*1.ÖRNEK MALLOC*/

int main()
{
    int n, *isaretci, toplam = 0;
    printf("Toplanacak eleman sayisini giriniz :");
    scanf("%d", &n);
    isaretci = (int*) malloc(n * sizeof(int)); //Kaç adet yer açka istiyorsak o çarpı açacağımız veri türünün boyutu kadar yer açıyor.
    if(isaretci == NULL) //Bellek ayırma işleminin başarısız olması durumunda.
    {
        printf("Hata! Bellek ayirma islemi basarisiz oldu.");
        exit(0);
    }
    printf("Toplanacak elemanlari giriniz :");
    for(int i = 0; i < n; i++)
    {
        scanf("%d", isaretci + i); //Değerleri okuyup hafızada açtığımız alana kaydırmak.
        toplam += *(isaretci + i); //Ve bu pointer'ların işaret ettiği değerleri toplama eklemek burdaki mevzu.
    }
    printf("Toplam = %d", toplam);
    free(isaretci); //Ayrılmış olan belleği serbest bırak.
    return 0;
}