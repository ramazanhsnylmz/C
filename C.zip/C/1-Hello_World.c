#include <stdio.h>

int main()
{
/*1.ÖRNEK MERHABA DÜNYA*/
printf("Merhaba Dunya");
return 0;
}